---
---

[&#x213C;](#idxXXX)<br id="idx000">
# {{ site.title }}

This [GitHub Page](https://pages.github.com/) is hosted at [GitHub.com]({{ site.urlgithub }}).
I am {{ site.author }}, {{ site.address }}

[&#x213C;](#)<br id="idx002">
# Jilid

* Jilid 2
  * [Juz 5 Surah 4: An-Nissa&#39;](#idx05004) --- (Jilid 2 Halaman 244)

[&#x213C;](#)<br id="idx05004">
# Jilid 2
## Juz 5 Surah 4: An-Nisaa&#39; (Jilid 2 Halaman 244)

| Q4:024-025 --- 2 247 |

[&#x213C;](#)<br id="idxXXX">

